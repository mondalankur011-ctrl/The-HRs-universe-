# thehruniverse.com

Static site — no build step needed.

## Structure
```
thehruniverse/
├── index.html   (links styles.css and script.js)
├── styles.css
└── script.js
```

## Push to GitHub
```bash
cd thehruniverse
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

## Deploy on Vercel
1. Go to vercel.com → **Add New Project**
2. Import the GitHub repo you just pushed
3. Framework Preset: **Other** (it's plain HTML/CSS/JS, no build command needed)
4. Leave Build Command and Output Directory blank
5. Deploy

Vercel will serve `index.html` from the root automatically. Once live, connect your `thehruniverse.com` domain under Project Settings → Domains.
